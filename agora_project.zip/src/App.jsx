import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import AgoraUIKit, {layout } from 'agora-react-uikit';

import './App.css'

function App() {
  const [count, setCount] = useState(0)
  const [isHost, setHost] = useState(false)
  const [isPinned, setPinned] = useState(true)
  const [videocall, setVideocall] = useState(true)
  const styles = {
    container: { width: '100vw', height: '95vh', overflow : 'hidden', minHeight : '400px', display: 'flex',  justifyContent : 'center', flex: 1},
    heading: { textAlign: 'center', marginBottom: 0 },
    videoContainer: { display: 'flex', flexDirection: 'column', flex: 1, justifyContent : 'center' },
    // videoContainer: { overflow : 'hidden' },
    nav: { display: 'flex', zIndex : 12121121, justifyContent: 'end', right : '10px', gap : '4px', position : 'fixed', },
    btn: { backgroundColor: '#007bff', cursor: 'pointer', borderRadius: 5, padding: 5, color: '#ffffff', fontSize: 20 },
  }
  const props = {
    rtcProps: {
      appId: '84b9c536d1fe47db8eda6dd3ac0d6b0a',
      channel: 'test',
      token: null, // pass in channel token if the app is in secure mode
      layout: isPinned ? layout.pin : layout.grid,
    },
    callbacks: {
      EndCall: () => setVideocall(false)
    },
    styleProps: {
      localBtnContainer: {backgroundColor: 'red', overflow : 'hidden', width : '200px'}
    }
  }
  return (
    <>
      <div style={styles.container}>
      {videocall ? (
        <>
        <div style={styles.nav}>
            {/* <p style={{ fontSize: 20, width: 200, color : 'black' }}>You're {isHost ? 'a host' : 'an audience'}</p> */}
            <p style={styles.btn} onClick={() => setHost(!isHost)}>{isHost ? 'Give up host' : 'Become host'}</p>
            <p style={styles.btn} onClick={() => setPinned(!isPinned)}>{isPinned ? 'Full' : 'Scale'}</p>
          </div>
        <AgoraUIKit
          rtcProps={props.rtcProps}
          callbacks={props.callbacks}
          styleProps={props.styleProps}
          />
          </>
      ) : (
        <h3 style={styles.btn} onClick={() => setVideocall(true)}>Start Call</h3>
      )}
    </div>
    </>
  )
}

export default App
